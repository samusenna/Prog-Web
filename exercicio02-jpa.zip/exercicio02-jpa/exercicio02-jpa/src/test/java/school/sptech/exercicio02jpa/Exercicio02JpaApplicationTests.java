package school.sptech.exercicio02jpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Exercicio02JpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
