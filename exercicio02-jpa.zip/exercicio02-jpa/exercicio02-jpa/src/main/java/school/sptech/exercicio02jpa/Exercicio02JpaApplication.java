package school.sptech.exercicio02jpa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Exercicio02JpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(Exercicio02JpaApplication.class, args);
	}

}
